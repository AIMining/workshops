This Mac OSX driver for CH340 is developed jointly by
CodeBender (http://codebender.cc) and
Rayshobby (http://rayshobby.net).
